/* eslint-disable prettier/prettier */
import withPrivateRoute from "../../hocs/withPrivateRoute";
import styled from "styled-components";

import LeftPanelSide from "./components/LeftPanel";
import RightPanelSide from "./components/RightPanel";
import HeaderActions from "./components/HeaderActions";
import LeftSideProfileSection from "./components/LeftSideProfileSection";
import { useState } from "react";

const Project = () => {

  const [slideChats, setSlideChats] = useState([]);
  const [slideVideos, setSlideVideos] = useState([]);
  const [slidesSelectedVideo, setSlidesSelectedVideo] = useState("");
  const [slides, setSlides] = useState([])
  const [currebtSlides, setCurrentSlides] = useState([])


  return (
    <Wrapper>
      <HeaderActions />
      <PageLayout>
        <LeftSideProfileSection />
        <LeftPanelSide
        // slideChats={slideChats}
        // setSlideChats={setSlideChats}
        // slideVideos={slideVideos}
        // setSlideVideos={setSlideVideos}
        // slidesSelectedVideo={slidesSelectedVideo}
        // setSlidesSelectedVideo={setSlidesSelectedVideo}
        />
        <RightPanelSide />
      </PageLayout>
    </Wrapper>
  );
};

export default withPrivateRoute(Project);

const Wrapper = styled.div`
  width: 100%;
  // height: 100vh;

  overflow: hidden;

  background: ${({ theme }) =>
    theme.primaryBackground};
`;

const PageLayout = styled.div`
  display: flex;
  width: 100%;
  height: 100%;
  overflow: hidden;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`;