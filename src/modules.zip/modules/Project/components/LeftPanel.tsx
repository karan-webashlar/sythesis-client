import styled, { keyframes } from "styled-components";
import ChatInput from "../../../components/ChatInput/ChatInput";
import { useEffect, useRef, useState } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Message {
  id: string;
  role: "user" | "ai";
  content: string;
  timestamp: string;
  videoId?: string; // if AI reply is linked to a video
}

interface VideoItem {
  id: string;
  title: string;
  prompt: string;
  thumbnail: string;
  duration: string;
  status: "done" | "generating" | "failed";
  createdAt: string;
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const INITIAL_MESSAGES: Message[] = [
  {
    id: "1",
    role: "ai",
    content:
      "Hi! I'm ready to help you generate your AI Product Ad video. Describe the scene, mood, or style you have in mind.",
    timestamp: "10:00 AM",
  },
  {
    id: "2",
    role: "user",
    content:
      "I want a cinematic product ad for a sleek black smartwatch. Dramatic lighting, slow motion, dark background.",
    timestamp: "10:01 AM",
  },
  {
    id: "3",
    role: "ai",
    content:
      "Great concept! A dark, dramatic approach works perfectly for luxury tech. I'll use a deep black background with a single strong key light to highlight the watch face. The slow-motion reveal will emphasize craftsmanship.",
    timestamp: "10:01 AM",
    videoId: "v1",
  },
  {
    id: "4",
    role: "user",
    content: "Yes! And can you add a voiceover that says 'Time, redefined'?",
    timestamp: "10:03 AM",
  },
  {
    id: "5",
    role: "ai",
    content:
      "Perfect tagline — short and powerful. I'll pair it with a deep, calm voice tone around the 3-second mark as the watch rotates into frame.",
    timestamp: "10:03 AM",
    videoId: "v2",
  },
];

const VIDEO_LIST: VideoItem[] = [
  {
    id: "v1",
    title: "Smartwatch Cinematic",
    prompt: "Cinematic product ad, dramatic lighting, slow motion, dark background.",
    thumbnail: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&auto=format&fit=crop",
    duration: "0:15",
    status: "done",
    createdAt: "10:01 AM",
  },
  {
    id: "v2",
    title: "Watch Voiceover Reveal",
    prompt: "Slow rotation reveal, voiceover 'Time, redefined', deep calm tone.",
    thumbnail: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=200&auto=format&fit=crop",
    duration: "0:20",
    status: "generating",
    createdAt: "10:03 AM",
  },
  {
    id: "v3",
    title: "Lens Flare Edit",
    prompt: "Subtle lens flare effect on watch face close-up.",
    thumbnail: "https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?w=200&auto=format&fit=crop",
    duration: "0:12",
    status: "done",
    createdAt: "10:05 AM",
  },
];

// ─── Icons ────────────────────────────────────────────────────────────────────

const SettingsIcon = () => (
  <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
    <circle cx="7.5" cy="7.5" r="2" stroke="currentColor" strokeWidth="1.4" />
    <path
      d="M7.5 1.5V3M7.5 12V13.5M1.5 7.5H3M12 7.5H13.5M3.4 3.4L4.5 4.5M10.5 10.5L11.6 11.6M3.4 11.6L4.5 10.5M10.5 4.5L11.6 3.4"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinecap="round"
    />
  </svg>
);

const RenameIcon = () => (
  <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
    <path
      d="M9.5 2L12.5 5L5 12.5H2V9.5L9.5 2Z"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const CloseIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M2 2L12 12M12 2L2 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const PlayIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M3 1.5L12.5 7L3 12.5V1.5Z" fill="currentColor" />
  </svg>
);

const SpinnerIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.5" strokeDasharray="8 6" strokeLinecap="round" />
  </svg>
);

const VideoThumbIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <rect x="1" y="3" width="10" height="10" rx="1.5" stroke="currentColor" strokeWidth="1.3" />
    <path d="M11 6.2L15 4V12L11 9.8V6.2Z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
  </svg>
);

const AiAvatarIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <rect width="16" height="16" rx="8" fill="url(#aigrad)" />
    <path d="M5 8.5L7 10.5L11 6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    <defs>
      <linearGradient id="aigrad" x1="0" y1="0" x2="16" y2="16">
        <stop stopColor="#0063B4" />
        <stop offset="1" stopColor="#009AF7" />
      </linearGradient>
    </defs>
  </svg>
);

// ─── Component ────────────────────────────────────────────────────────────────

interface LeftPanelSideProps {
  slideName?: string;
  onSettings?: () => void;
  onRename?: () => void;
  onClose?: () => void;
}

const LeftPanelSide = ({ slideName = "AI Product Ad" }: LeftPanelSideProps) => {
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [videos] = useState<VideoItem[]>(VIDEO_LIST);
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "ai",
        content:
          "Got it! I'm processing your request and will update the video generation accordingly. Your new video will be ready shortly.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        videoId: videos[0]?.id,
      };
      setMessages((prev) => [...prev, aiMsg]);
    }, 1500);
  };

  const handleVideoClick = (videoId: string) => {
    setActiveVideoId(videoId === activeVideoId ? null : videoId);
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  useEffect(() => {
    LeftPanelSide;
  }, []);

  const activeVideo = videos.find((v) => v.id === activeVideoId);

  return (
    <LeftPanel>
      <LeftHeader>
        <HeaderTitle>{slideName}</HeaderTitle>
        <HeaderActions>
          <ActionBtn title="Settings">
            <SettingsIcon />
          </ActionBtn>
          <ActionBtn title="Rename">
            <RenameIcon />
          </ActionBtn>
          <ActionBtn title="Close">
            <CloseIcon />
          </ActionBtn>
        </HeaderActions>
      </LeftHeader>

      <PanelBody>
        <ChatSection>
          <ChatMessages>
            <PanelHeader>
              <SectionLabel style={{ margin: 0 }}>Conversation</SectionLabel>
            </PanelHeader>
            {messages.map((msg) => (
              <MessageRow key={msg.id} $role={msg.role}>
                {msg.role === "ai" && (
                  <Avatar>
                    <AiAvatarIcon />
                  </Avatar>
                )}
                <MessageBubble $role={msg.role}>
                  <BubbleText>{msg.content}</BubbleText>

                  {msg.role === "ai" && msg.videoId && (
                    <LinkedVideoCard
                      $active={activeVideoId === msg.videoId}
                      onClick={() => handleVideoClick(msg.videoId!)}
                    >
                      {(() => {
                        const v = videos.find((vv) => vv.id === msg.videoId);
                        if (!v) return null;
                        return (
                          <>
                            <LinkedThumb src={v.thumbnail} alt={v.title} />
                            <LinkedVideoInfo>
                              <LinkedVideoTitle>{v.title}</LinkedVideoTitle>
                              <LinkedVideoMeta>
                                <StatusDot $status={v.status} />
                                {v.status === "generating" ? "Generating…" : v.duration}
                              </LinkedVideoMeta>
                            </LinkedVideoInfo>
                            <PlayBadge>{v.status === "generating" ? <SpinnerIcon /> : <PlayIcon />}</PlayBadge>
                          </>
                        );
                      })()}
                    </LinkedVideoCard>
                  )}

                  <Timestamp>{msg.timestamp}</Timestamp>
                </MessageBubble>
              </MessageRow>
            ))}

            {isTyping && (
              <MessageRow $role="ai">
                <Avatar>
                  <AiAvatarIcon />
                </Avatar>
                <MessageBubble $role="ai">
                  <TypingDots>
                    <Dot $delay="0s" />
                    <Dot $delay="0.18s" />
                    <Dot $delay="0.36s" />
                  </TypingDots>
                </MessageBubble>
              </MessageRow>
            )}

            <div ref={chatEndRef} />
          </ChatMessages>

          <VideoSection>
            <PanelHeader>
              <SectionLabel style={{ margin: 0 }}>
                <VideoThumbIcon />
                Videos ({videos.length})
              </SectionLabel>
            </PanelHeader>
            <VideoList>
              {videos.map((video) => (
                <VideoCard
                  key={video.id}
                  $active={activeVideoId === video.id}
                  onClick={() => handleVideoClick(video.id)}
                >
                  <VideoThumbWrapper>
                    <VideoThumbImg src={video.thumbnail} alt={video.title} />
                    {video.status === "generating" ? (
                      <GeneratingOverlay>
                        <SpinningIcon />
                      </GeneratingOverlay>
                    ) : (
                      <PlayOverlay className="play-overlay">
                        <PlayIcon />
                      </PlayOverlay>
                    )}
                    <DurationBadge>{video.duration}</DurationBadge>
                  </VideoThumbWrapper>

                  <VideoCardInfo>
                    <VideoCardTitle>{video.title}</VideoCardTitle>
                    <VideoCardPrompt>{video.prompt}</VideoCardPrompt>
                    <VideoCardMeta>
                      <StatusPill $status={video.status}>
                        {video.status === "generating" ? "Generating" : video.status === "done" ? "Done" : "Failed"}
                      </StatusPill>
                      <VideoCardTime>{video.createdAt}</VideoCardTime>
                    </VideoCardMeta>
                  </VideoCardInfo>
                </VideoCard>
              ))}
            </VideoList>
          </VideoSection>
        </ChatSection>

        <InputArea>
          <ChatInput
            value={inputValue}
            onChange={setInputValue}
            onSend={handleSend}
            width="100%"
            minHeight="40px"
            maxHeight="140px"
            attachedFiles={attachedFiles}
            setAttachedFiles={setAttachedFiles}
            chips={[{ title: "Video", isActive: true }, { title: "Image" }]}
          />
        </InputArea>
      </PanelBody>
    </LeftPanel>
  );
};

const bounce = keyframes`
  0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
  40% { transform: translateY(-5px); opacity: 1; }
`;

const spin = keyframes`
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
`;

const LeftPanel = styled.div`
  width: 40%;
  min-width: 40%;
  max-width: 40%;
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: ${({ theme }) => theme.primaryBackground};
  border-right: 1px solid ${({ theme }) => theme.editorLineBorder};
  overflow: hidden;
  flex-shrink: 0;

  @media (max-width: 768px) {
    width: 100%;
    max-width: 100%;
    height: 50vh;
    border-right: none;
    border-bottom: 1px solid ${({ theme }) => theme.editorLineBorder};
  }
`;

const LeftHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 14px 13px;
  border-bottom: 1px solid ${({ theme }) => theme.editorLineBorder};
  flex-shrink: 0;
  gap: 10px;
`;

const HeaderTitle = styled.span`
  font-family: "Montserrat", sans-serif;
  font-weight: 600;
  font-size: 14px;
  color: ${({ theme }) => theme.primaryText};
  flex: 1;
  letter-spacing: -0.2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const HeaderActions = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
`;

const ActionBtn = styled.button<{ $danger?: boolean }>`
  all: unset;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  color: ${({ $danger, theme }) => ($danger ? "#FF6C76" : theme.primaryText)};
  opacity: 0.55;
  transition: opacity 0.15s, background 0.15s;

  &:hover {
    opacity: 1;
    background: ${({ $danger }) => ($danger ? "rgba(255,108,118,0.1)" : "rgba(128,128,128,0.1)")};
  }
`;

const PanelBody = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: hidden;
`;

const ChatSection = styled.div`
  display: flex;
  flex-direction: row;
  flex: 1;
  overflow: hidden;
  min-height: 0;
  width: 100%;
`;

const PanelHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  border-bottom: 1px solid ${({ theme }) => theme.editorLineBorder};
  flex-shrink: 0;
  background: ${({ theme }) => theme.primaryBackground};
`;

const SectionLabel = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
  font-family: "Montserrat", sans-serif;
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: ${({ theme }) => theme.editorFileUpload};
`;

const ChatMessages = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 4px 14px 8px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: 70%;

  ::-webkit-scrollbar {
    width: 4px;
  }
  ::-webkit-scrollbar-track {
    background: transparent;
  }
  ::-webkit-scrollbar-thumb {
    background: ${({ theme }) => theme.editorLineBorder};
    border-radius: 4px;
  }
`;

const MessageRow = styled.div<{ $role: "user" | "ai" }>`
  display: flex;
  align-items: flex-end;
  gap: 8px;
  flex-direction: ${({ $role }) => ($role === "user" ? "row-reverse" : "row")};
`;

const Avatar = styled.div`
  width: 22px;
  height: 22px;
  flex-shrink: 0;
  margin-bottom: 2px;
`;

const MessageBubble = styled.div<{ $role: "user" | "ai" }>`
  max-width: 78%;
  padding: 9px 12px 6px;
  border-radius: ${({ $role }) => ($role === "user" ? "14px 14px 4px 14px" : "14px 14px 14px 4px")};
  background: ${({ $role, theme }) =>
    $role === "user"
      ? theme.button
      : theme.messageBackground ?? (theme.primaryBackground === "#F0F0F3" ? "#EAEAED" : "#232528")};
  box-shadow: ${({ $role, theme }) => ($role === "user" ? theme.buttonShadow : "none")};
  display: flex;
  flex-direction: column;
  gap: 6px;
`;

const BubbleText = styled.p`
  margin: 0;
  font-family: "Montserrat", sans-serif;
  font-size: 12px;
  line-height: 1.55;
  color: ${({ theme }) => theme.primaryText};
  word-break: break-word;
`;

const Timestamp = styled.span`
  font-family: "Montserrat", sans-serif;
  font-size: 9px;
  color: ${({ theme }) => theme.primaryText};
  opacity: 0.35;
  align-self: flex-end;
`;

const LinkedVideoCard = styled.button<{ $active: boolean }>`
  all: unset;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid ${({ $active, theme }) => ($active ? theme.activeMenu : theme.editorLineBorder)};
  background: ${({ theme }) => (theme.primaryBackground === "#F0F0F3" ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.25)")};
  padding: 6px 8px;
  transition: border-color 0.15s, background 0.15s;

  &:hover {
    border-color: ${({ theme }) => theme.activeMenu};
  }
`;

const LinkedThumb = styled.img`
  width: 38px;
  height: 28px;
  object-fit: cover;
  border-radius: 5px;
  flex-shrink: 0;
`;

const LinkedVideoInfo = styled.div`
  flex: 1;
  min-width: 0;
`;

const LinkedVideoTitle = styled.p`
  margin: 0;
  font-family: "Montserrat", sans-serif;
  font-size: 10px;
  font-weight: 600;
  color: ${({ theme }) => theme.primaryText};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const LinkedVideoMeta = styled.p`
  margin: 2px 0 0;
  font-family: "Montserrat", sans-serif;
  font-size: 9px;
  color: ${({ theme }) => theme.editorFileUpload};
  display: flex;
  align-items: center;
  gap: 4px;
`;

const PlayBadge = styled.div`
  color: ${({ theme }) => theme.activeMenu};
  flex-shrink: 0;
`;

const StatusDot = styled.span<{ $status: string }>`
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: ${({ $status }) => ($status === "done" ? "#31DFCA" : $status === "generating" ? "#FF8C00" : "#FF6C76")};
  display: inline-block;
  flex-shrink: 0;
`;

const TypingDots = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 2px;
`;

const Dot = styled.span<{ $delay: string }>`
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: ${({ theme }) => theme.activeMenu};
  animation: ${bounce} 1.2s ease infinite;
  animation-delay: ${({ $delay }) => $delay};
`;

const InputArea = styled.div`
  padding: 10px 12px 12px;
  flex-shrink: 0;
  border-top: 1px solid ${({ theme }) => theme.editorLineBorder};
`;

const VideoSection = styled.div`
  flex-shrink: 0;
  width: 30%;
  display: flex;
  flex-direction: column;
  border-top: 1px solid ${({ theme }) => theme.editorLineBorder};
  overflow-y: auto;
  gap: 12px;
`;

const VideoList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  overflow-y: auto;
  padding: 4px 14px 12px;

  ::-webkit-scrollbar {
    width: 4px;
  }
  ::-webkit-scrollbar-track {
    background: transparent;
  }
  ::-webkit-scrollbar-thumb {
    background: ${({ theme }) => theme.editorLineBorder};
    border-radius: 4px;
  }
`;

const VideoCard = styled.button<{ $active: boolean }>`
  all: unset;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px;
  border-radius: 10px;
  border: 1px solid ${({ $active, theme }) => ($active ? theme.activeMenu : theme.editorLineBorder)};
  background: ${({ $active, theme }) =>
    $active
      ? theme.primaryBackground === "#F0F0F3"
        ? "rgba(0,154,247,0.06)"
        : "rgba(0,154,247,0.08)"
      : "transparent"};
  transition: border-color 0.15s, background 0.15s;

  &:hover {
    border-color: ${({ theme }) => theme.activeMenu};
    .play-overlay {
      opacity: 1;
    }
  }
`;

const VideoThumbWrapper = styled.div`
  position: relative;
  width: 64px;
  height: 44px;
  border-radius: 6px;
  overflow: hidden;
  flex-shrink: 0;
`;

const VideoThumbImg = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`;

const PlayOverlay = styled.div`
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  opacity: 0;
  transition: opacity 0.15s;
  border-radius: 6px;
`;

const GeneratingOverlay = styled.div`
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.55);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ff8c00;
  border-radius: 6px;
`;

const SpinningIcon = styled.div`
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 140, 0, 0.3);
  border-top-color: #ff8c00;
  border-radius: 50%;
  animation: ${spin} 0.8s linear infinite;
`;

const DurationBadge = styled.span`
  position: absolute;
  bottom: 3px;
  right: 4px;
  font-family: "Montserrat", sans-serif;
  font-size: 8px;
  font-weight: 600;
  color: #fff;
  background: rgba(0, 0, 0, 0.6);
  padding: 1px 4px;
  border-radius: 3px;
`;

const VideoCardInfo = styled.div`
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 3px;
`;

const VideoCardTitle = styled.p`
  margin: 0;
  font-family: "Montserrat", sans-serif;
  font-size: 11px;
  font-weight: 600;
  color: ${({ theme }) => theme.primaryText};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const VideoCardPrompt = styled.p`
  margin: 0;
  font-family: "Montserrat", sans-serif;
  font-size: 9.5px;
  color: ${({ theme }) => theme.editorFileUpload};
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  line-height: 1.4;
`;

const VideoCardMeta = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 2px;
`;

const StatusPill = styled.span<{ $status: string }>`
  font-family: "Montserrat", sans-serif;
  font-size: 9px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 20px;
  background: ${({ $status }) =>
    $status === "done"
      ? "rgba(49,223,202,0.15)"
      : $status === "generating"
      ? "rgba(255,140,0,0.15)"
      : "rgba(255,108,118,0.15)"};
  color: ${({ $status }) => ($status === "done" ? "#31DFCA" : $status === "generating" ? "#FF8C00" : "#FF6C76")};
`;

const VideoCardTime = styled.span`
  font-family: "Montserrat", sans-serif;
  font-size: 9px;
  color: ${({ theme }) => theme.editorFileUpload};
  opacity: 0.7;
`;

export default LeftPanelSide;
