import { useState } from "react";
import styled from "styled-components";

// ─── Icons ────────────────────────────────────────────────────────────────────

const AvatarsIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <circle cx="10" cy="6" r="3.5" stroke="currentColor" strokeWidth="1.5" />
    <path
      d="M3 17.5C3 13.91 6.13 11 10 11C13.87 11 17 13.91 17 17.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

const ScriptIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <rect x="4" y="2.5" width="12" height="15" rx="2" stroke="currentColor" strokeWidth="1.5" />
    <path d="M7 7H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M7 10H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M7 13H10.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const BGIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <rect x="2.5" y="3.5" width="15" height="13" rx="2" stroke="currentColor" strokeWidth="1.5" />
    <circle cx="7" cy="8" r="1.5" stroke="currentColor" strokeWidth="1.3" />
    <path
      d="M2.5 13.5L6.5 9.5L9.5 12.5L12.5 9L17.5 14.5"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const TextIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path d="M4 5H16" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    <path d="M10 5V16" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    <path d="M7.5 16H12.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const MusicIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path
      d="M8 15V5.5L16 4V13.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="6" cy="15" r="2" stroke="currentColor" strokeWidth="1.4" />
    <circle cx="14" cy="13.5" r="2" stroke="currentColor" strokeWidth="1.4" />
  </svg>
);

const ElementsIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.5" />
    <circle cx="10" cy="10" r="3" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

const MediaIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <rect x="2.5" y="3.5" width="15" height="13" rx="2" stroke="currentColor" strokeWidth="1.5" />
    <path
      d="M8 8L13.5 10.5L8 13V8Z"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinejoin="round"
      fill="currentColor"
    />
  </svg>
);

// ─── Types ────────────────────────────────────────────────────────────────────

export type SidebarItemKey = "avatars" | "script" | "bg" | "text" | "music" | "elements" | "media";

interface SidebarItem {
  key: SidebarItemKey;
  label: string;
  icon: React.ReactNode;
}

interface LeftSideProfileSectionProps {
  activeItem?: SidebarItemKey;
  onItemClick?: (key: SidebarItemKey) => void;
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const SIDEBAR_ITEMS: SidebarItem[] = [
  { key: "avatars", label: "Avatars", icon: <AvatarsIcon /> },
  { key: "script", label: "Script", icon: <ScriptIcon /> },
  { key: "bg", label: "BG", icon: <BGIcon /> },
  { key: "text", label: "Text", icon: <TextIcon /> },
  { key: "music", label: "Music", icon: <MusicIcon /> },
  { key: "elements", label: "Elements", icon: <ElementsIcon /> },
  { key: "media", label: "Media", icon: <MediaIcon /> },
];

// ─── Component ────────────────────────────────────────────────────────────────

const LeftSideProfileSection = ({ activeItem: controlledActive, onItemClick }: LeftSideProfileSectionProps) => {
  const [internalActive, setInternalActive] = useState<SidebarItemKey>("script");

  const activeItem = controlledActive ?? internalActive;

  const handleClick = (key: SidebarItemKey) => {
    setInternalActive(key);
    onItemClick?.(key);
  };

  return (
    <Sidebar>
      {SIDEBAR_ITEMS.map(({ key, label, icon }) => (
        <NavItem
          key={key}
          $active={activeItem === key}
          onClick={() => handleClick(key)}
          aria-label={label}
          aria-current={activeItem === key ? "page" : undefined}
        >
          <IconWrapper $active={activeItem === key}>{icon}</IconWrapper>
          <Label $active={activeItem === key}>{label}</Label>
        </NavItem>
      ))}
    </Sidebar>
  );
};

// ─── Styles ───────────────────────────────────────────────────────────────────

const Sidebar = styled.nav`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  width: 70px;
  padding: 12px 6px;
  background-color: ${({ theme }) => theme.secondaryBackground};
  height: 100%;
  box-sizing: border-box;
  flex-shrink: 0;
  border-right: 1px solid rgba(255, 255, 255, 0.05);
`;

const NavItem = styled.button<{ $active: boolean }>`
  all: unset;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  width: 58px;
  padding: 8px 0;
  border-radius: 10px;
  transition: background 0.15s ease, opacity 0.15s ease;
  position: relative;

  background: ${({ $active, theme }) =>
    $active
      ? theme.primaryBackground === "#F0F0F3"
        ? "#FFFFFF" /* light theme active */
        : "rgba(255,255,255,0.1)" /* dark theme active */
      : "transparent"};

  box-shadow: ${({ $active, theme }) => ($active ? theme.cardShadow : "none")};

  &:hover {
    background: ${({ $active, theme }) =>
      $active
        ? theme.primaryBackground === "#F0F0F3"
          ? "#FFFFFF"
          : "rgba(255,255,255,0.1)"
        : "rgba(255,255,255,0.05)"};
  }

  &:active {
    transform: scale(0.95);
  }
`;

const IconWrapper = styled.span<{ $active: boolean }>`
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${({ $active, theme }) => ($active ? theme.activeMenu : theme.sidebarIcon)};
  opacity: ${({ $active }) => ($active ? 1 : 0.6)};
  transition: color 0.15s ease, opacity 0.15s ease;

  ${NavItem}:hover & {
    opacity: 1;
  }
`;

const Label = styled.span<{ $active: boolean }>`
  font-family: "Montserrat", sans-serif;
  font-size: 10px;
  font-weight: ${({ $active }) => ($active ? 600 : 400)};
  line-height: 1;
  color: ${({ $active, theme }) => ($active ? theme.activeMenu : theme.sidebarMenuText)};
  opacity: ${({ $active }) => ($active ? 1 : 0.6)};
  transition: color 0.15s ease, opacity 0.15s ease;
  text-align: center;
  white-space: nowrap;

  ${NavItem}:hover & {
    opacity: 1;
  }
`;

export default LeftSideProfileSection;
