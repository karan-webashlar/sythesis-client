/* eslint-disable prettier/prettier */
import styled, { keyframes } from "styled-components";
import { useState } from "react";

interface Slide {
  id: string;
  label: string;
  thumbnail: string;
  duration: string;
  active?: boolean;
}

const SLIDES: Slide[] = [
  {
    id: "s1",
    label: "Slide 1",
    thumbnail: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&auto=format&fit=crop",
    duration: "00:05",
    active: true,
  },
  {
    id: "s2",
    label: "Slide 2",
    thumbnail: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=300&auto=format&fit=crop",
    duration: "00:08",
  },
  {
    id: "s3",
    label: "Slide 3",
    thumbnail: "https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?w=300&auto=format&fit=crop",
    duration: "00:06",
  },
  {
    id: "s4",
    label: "Slide 4",
    thumbnail: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=300&auto=format&fit=crop",
    duration: "00:04",
  },
  {
    id: "s5",
    label: "Slide 5",
    thumbnail: "https://images.unsplash.com/photo-1517420704952-d9f39e95b43e?w=300&auto=format&fit=crop",
    duration: "00:07",
  },
  {
    id: "s6",
    label: "Slide 6",
    thumbnail: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=300&auto=format&fit=crop",
    duration: "00:05",
  },
];

// ─── Icons ────────────────────────────────────────────────────────────────────

const PlayIcon = () => (
  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
    <path d="M7 4.5L18 11L7 17.5V4.5Z" fill="currentColor" />
  </svg>
);

const MoreIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <circle cx="2.5" cy="7" r="1.2" fill="currentColor" />
    <circle cx="7" cy="7" r="1.2" fill="currentColor" />
    <circle cx="11.5" cy="7" r="1.2" fill="currentColor" />
  </svg>
);

const AddIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M7 2V12M2 7H12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
);

const RightPanelSide = () => {
  const [activeSlide, setActiveSlide] = useState<string>("s1");
  const [isPlaying, setIsPlaying] = useState(false);

  const currentSlide = SLIDES.find((s) => s.id === activeSlide) ?? SLIDES[0];

  const totalSeconds = SLIDES.reduce((acc, s) => {
    const [m, sec] = s.duration.split(":").map(Number);
    return acc + m * 60 + sec;
  }, 0);
  const totalFormatted = `${String(Math.floor(totalSeconds / 60)).padStart(2, "0")}:${String(totalSeconds % 60).padStart(2, "0")}`;

  return (
    <Wrapper>
      <RightHeader>
        <RightHeaderLeft>
          <RightTitle>Preview</RightTitle>
        </RightHeaderLeft>
      </RightHeader>

      {/* ── Video Preview ── */}
      <Content>
        <PreviewCard>
          <PreviewImage src={currentSlide.thumbnail} alt="preview" />
          <Overlay>
            <PlayButton onClick={() => setIsPlaying((p) => !p)} $playing={isPlaying}>
              {isPlaying ? (
                <PauseLines>
                  <span />
                  <span />
                </PauseLines>
              ) : (
                <PlayIcon />
              )}
            </PlayButton>
          </Overlay>
        </PreviewCard>
      </Content>

      {/* ── Slides Strip ── */}
      <SlidesSection>
        <SlidesMeta>
          <EstimatedLabel>
            Estimated video length: <strong>{totalFormatted}</strong>
          </EstimatedLabel>
          <AddSlideBtn title="Add slide">
            <AddIcon />
          </AddSlideBtn>
        </SlidesMeta>

        <SlidesTrack>
          {SLIDES.map((slide, idx) => (
            <SlideItem
              key={slide.id}
              $active={activeSlide === slide.id}
              onClick={() => setActiveSlide(slide.id)}
            >
              <SlideThumbWrapper $active={activeSlide === slide.id}>
                <SlideThumbImg src={slide.thumbnail} alt={slide.label} />
                {activeSlide === slide.id && (
                  <ActiveIndicator>
                    <PlayIcon />
                  </ActiveIndicator>
                )}
                <SlideDurationBadge>{slide.duration}</SlideDurationBadge>
              </SlideThumbWrapper>

              <SlideFooter>
                <SlideIndex>{idx + 1}</SlideIndex>
                <SlideMoreBtn
                  onClick={(e) => e.stopPropagation()}
                  title="Options"
                >
                  <MoreIcon />
                </SlideMoreBtn>
              </SlideFooter>
            </SlideItem>
          ))}
        </SlidesTrack>
      </SlidesSection>
    </Wrapper>
  );
};

export default RightPanelSide;

// ─── Animations ───────────────────────────────────────────────────────────────

const pulse = keyframes`
  0%, 100% { box-shadow: 0 0 0 0 rgba(0,154,247,0.35); }
  50% { box-shadow: 0 0 0 8px rgba(0,154,247,0); }
`;

/* ─── Styles ─────────────────────────────────────────────────────────────────*/

const Wrapper = styled.div`
  width: 55%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: ${({ theme }) => theme.primaryBackground};

  @media (max-width: 768px) {
    width: 100%;
    height: 50vh;
  }
`;

const RightHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px 13px;
  border-bottom: 1px solid ${({ theme }) => theme.editorLineBorder};
  flex-shrink: 0;
`;

const RightHeaderLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const RightTitle = styled.span`
  font-family: "Montserrat", sans-serif;
  font-weight: 600;
  font-size: 14px;
  color: ${({ theme }) => theme.primaryText};
  letter-spacing: -0.2px;
`;

const StatusBadge = styled.span`
  padding: 2px 8px;
  border-radius: 20px;
  font-family: "Montserrat", sans-serif;
  font-size: 10px;
  font-weight: 600;
  background: rgba(0, 154, 247, 0.15);
  color: ${({ theme }) => theme.activeMenu};
  border: 1px solid rgba(0, 154, 247, 0.3);
`;

/* ── Video Preview ── */

const Content = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 18px 18px 12px;
  overflow: hidden;
  min-height: 0;
`;

const PreviewCard = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: 14px;
  overflow: hidden;
  background: ${({ theme }) => theme.editorDropDownContent ?? "#1a1b1e"};
  border: 1px solid ${({ theme }) => theme.editorLineBorder};
`;

const PreviewImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`;

const Overlay = styled.div`
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.18);
`;

const PlayButton = styled.button<{ $playing: boolean }>`
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: none;
  background: rgba(255, 255, 255, 0.14);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: white;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.18s, background 0.18s;
  animation: ${({ $playing }) => ($playing ? pulse : "none")} 1.8s ease infinite;

  &:hover {
    transform: scale(1.1);
    background: rgba(255, 255, 255, 0.22);
  }
`;

const PauseLines = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;

  span {
    display: block;
    width: 4px;
    height: 18px;
    background: white;
    border-radius: 2px;
  }
`;

/* ── Slides Strip ── */

const SlidesSection = styled.div`
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  border-top: 1px solid ${({ theme }) => theme.editorLineBorder};
  padding: 8px 0 10px;
  background: ${({ theme }) => theme.primaryBackground};
`;

const SlidesMeta = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 14px 6px;
`;

const EstimatedLabel = styled.span`
  font-family: "Montserrat", sans-serif;
  font-size: 9.5px;
  color: ${({ theme }) => theme.editorFileUpload};

  strong {
    color: ${({ theme }) => theme.primaryText};
    font-weight: 600;
  }
`;

const AddSlideBtn = styled.button`
  all: unset;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: ${({ theme }) => theme.editorFileUpload};
  transition: background 0.15s, color 0.15s;

  &:hover {
    background: ${({ theme }) => theme.editorLineBorder};
    color: ${({ theme }) => theme.primaryText};
  }
`;

const SlidesTrack = styled.div`
  display: flex;
  flex-direction: row;
  gap: 8px;
  overflow-x: auto;
  padding: 4px 14px 2px;

  ::-webkit-scrollbar {
    height: 3px;
  }
  ::-webkit-scrollbar-track {
    background: transparent;
  }
  ::-webkit-scrollbar-thumb {
    background: ${({ theme }) => theme.editorLineBorder};
    border-radius: 3px;
  }
`;

const SlideItem = styled.div<{ $active: boolean }>`
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
  cursor: pointer;
  width: 110px;
`;

const SlideThumbWrapper = styled.div<{ $active: boolean }>`
  position: relative;
  width: 110px;
  height: 68px;
  border-radius: 8px;
  overflow: hidden;
  border: 1.5px solid ${({ $active, theme }) => ($active ? theme.activeMenu : theme.editorLineBorder)};
  transition: border-color 0.15s;

  &:hover {
    border-color: ${({ theme }) => theme.activeMenu};
  }
`;

const SlideThumbImg = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`;

const ActiveIndicator = styled.div`
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.38);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 14px;
`;

const SlideDurationBadge = styled.span`
  position: absolute;
  bottom: 3px;
  right: 4px;
  font-family: "Montserrat", sans-serif;
  font-size: 8px;
  font-weight: 600;
  color: #fff;
  background: rgba(0, 0, 0, 0.6);
  padding: 1px 4px;
  border-radius: 3px;
`;

const SlideFooter = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2px;
`;

const SlideIndex = styled.span`
  font-family: "Montserrat", sans-serif;
  font-size: 9px;
  font-weight: 600;
  color: ${({ theme }) => theme.editorFileUpload};
`;

const SlideMoreBtn = styled.button`
  all: unset;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  color: ${({ theme }) => theme.editorFileUpload};
  transition: background 0.12s, color 0.12s;

  &:hover {
    background: ${({ theme }) => theme.editorLineBorder};
    color: ${({ theme }) => theme.primaryText};
  }
`;