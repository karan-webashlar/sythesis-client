/* eslint-disable prettier/prettier */
import withPrivateRoute from "../../hocs/withPrivateRoute";
import SidebarLayout from "../../layouts/SidebarLayout";
import styled from "styled-components";
import ProjectCard from "../../components/ProjectCard/ProjectCard";
import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import ChatInput from "../../components/ChatInput/ChatInput";

const mockProjects: any[] = [
  {
    projectId: "1",
    projectTypeId: "video",
    title: "AI Product Ad",
    description: "Cinematic product advertisement generated using AI.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "2",
    projectTypeId: "video",
    title: "Avatar Lipsync",
    description: "AI avatar speaking with realistic lipsync.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "3",
    projectTypeId: "video",
    title: "Social Media Reel",
    description: "Short cinematic reel generated from prompt.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "4",
    projectTypeId: "video",
    title: "Brand Story",
    description: "Emotional brand narrative with AI voiceover.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "1",
    projectTypeId: "video",
    title: "AI Product Ad",
    description: "Cinematic product advertisement generated using AI.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "2",
    projectTypeId: "video",
    title: "Avatar Lipsync",
    description: "AI avatar speaking with realistic lipsync.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "3",
    projectTypeId: "video",
    title: "Social Media Reel",
    description: "Short cinematic reel generated from prompt.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "4",
    projectTypeId: "video",
    title: "Brand Story",
    description: "Emotional brand narrative with AI voiceover.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "1",
    projectTypeId: "video",
    title: "AI Product Ad",
    description: "Cinematic product advertisement generated using AI.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "2",
    projectTypeId: "video",
    title: "Avatar Lipsync",
    description: "AI avatar speaking with realistic lipsync.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "3",
    projectTypeId: "video",
    title: "Social Media Reel",
    description: "Short cinematic reel generated from prompt.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "4",
    projectTypeId: "video",
    title: "Brand Story",
    description: "Emotional brand narrative with AI voiceover.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "1",
    projectTypeId: "video",
    title: "AI Product Ad",
    description: "Cinematic product advertisement generated using AI.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "2",
    projectTypeId: "video",
    title: "Avatar Lipsync",
    description: "AI avatar speaking with realistic lipsync.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "3",
    projectTypeId: "video",
    title: "Social Media Reel",
    description: "Short cinematic reel generated from prompt.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop",
  },
  {
    projectId: "4",
    projectTypeId: "video",
    title: "Brand Story",
    description: "Emotional brand narrative with AI voiceover.",
    updatedAt: "",
    image: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=1200&auto=format&fit=crop",
  },
];

const models: any[] =
  [
    "GPT-4o",
    "GPT-4.1",
    "Claude 3",
    "Gemini Pro",
  ]

const AiVideo = () => {

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [prompt, setPrompt] = useState("");
  const navigate = useNavigate()
  const [selectedModel, setSelectedModel] =
    useState("");

  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);

  const handleSend = () => {
    navigate("/ai-video/projects/1")
    console.log("Prompt:", prompt); console.log("Files:", attachedFiles); // API call here };
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;

    if (!files) return;

    const imageUrls = Array.from(files).map((file) =>
      URL.createObjectURL(file)
    );

    setUploadedImages((prev) => [...prev, ...imageUrls]);
    setShowAttachmentMenu(false)
  };

  const removeImage = (index: number) => {
    setUploadedImages((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <Wrapper>
      <SidebarLayout>
        <Content>
          <Container>
            <HeroSection>
              <HeroText>
                <PageTitle>Generate AI Videos</PageTitle>
                <PageSubtitle>from Prompt</PageSubtitle>
              </HeroText>

              <ChatInput
                value={prompt}
                onChange={setPrompt}
                onSend={handleSend}
                width="100%"
                minHeight="40px"
                maxHeight="140px"
                attachedFiles={attachedFiles}
                setAttachedFiles={setAttachedFiles}
                chips={[{ title: "Video", isActive: true, },
                { title: "Image", },]}
                onSelectModel={setSelectedModel}
                selectedModel={selectedModel}
                models={models}
              />
            </HeroSection>

            <ProjectsSection>
              <ProjectsHeader>
                <ProjectsLabel>My Projects</ProjectsLabel>
              </ProjectsHeader>
              <ProjectsGrid>
                {mockProjects.map((project) => (
                  <ProjectCard
                    key={project.projectId}
                    project={project}
                    title={project.title}
                    description={project.description}
                    projectTime={project.updatedAt}
                    image={project.image}
                  />
                ))}
              </ProjectsGrid>
            </ProjectsSection>
          </Container>
        </Content>
      </SidebarLayout>
    </Wrapper>
  );
};

// ── Layout ────────────────────────────────────────────────────────────────────

const Wrapper = styled.div`
  background-color: ${({ theme }) => theme.primaryBackground};
  width: 100%;
  height: 100vh;
  display: flex;
  overflow: hidden;
`;

const Content = styled.div`
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
  flex: 1;
  min-width: 0;
`;

const Container = styled.div`
  padding: 32px 32px 24px;
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  gap: 32px;

  @media (max-width: 768px) {
    padding: 20px 16px 16px;
    gap: 24px;
  }
`;

// ── Hero ──────────────────────────────────────────────────────────────────────

const HeroSection = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
  width: 100%;
  max-width: 680px;
  margin: 0 auto;
  padding-top: 20px;

  @media (max-width: 768px) {
    padding-top: 8px;
    gap: 16px;
  }
`;

const HeroText = styled.div`
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 2px;
`;

const PageTitle = styled.h1`
  font-family: "Montserrat", sans-serif;
  font-weight: 700;
  font-size: clamp(22px, 3vw, 32px);
  line-height: 1.15;
  letter-spacing: -0.5px;
  color: ${({ theme }) => theme.primaryText};
  margin: 0;
`;

const PageSubtitle = styled.span`
  font-family: "Montserrat", sans-serif;
  font-weight: 400;
  font-size: clamp(16px, 2vw, 22px);
  color: ${({ theme }) => theme.primaryText};
  opacity: 0.4;
  letter-spacing: -0.3px;
`;

// ── Projects ──────────────────────────────────────────────────────────────────

const ProjectsSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 14px;
  flex: 1;
  overflow: hidden;
  min-height: 0;
`;

const ProjectsHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const ProjectsLabel = styled.p`
  margin: 0;
  font-family: "Montserrat", sans-serif;
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: ${({ theme }) => theme.primaryText};
  opacity: 0.4;
`;

const ProjectsGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  overflow-y: auto;
  flex: 1;
  align-content: flex-start;
  padding-right: 4px;

  &::-webkit-scrollbar {
    width: 4px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 99px;
  }

  @media (max-width: 480px) {
    gap: 12px;
  }
`;

export default withPrivateRoute(AiVideo);